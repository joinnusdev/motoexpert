<?php
class App_Controller_Action_Portal extends App_Controller_Action
{

    public function init() 
    {
        parent::init();        
    }

}