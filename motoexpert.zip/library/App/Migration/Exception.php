<?php

class App_Migration_Exception extends Zend_Exception
{
}
