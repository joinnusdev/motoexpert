<?php

class Default_NoticiaController extends App_Controller_Action_Default
{

    public function init()
    {
        parent::init();
    }
    
    public function indexAction()
    {
        
    } 
    
    public function listarNoticia(){
        
    }
}

?>
